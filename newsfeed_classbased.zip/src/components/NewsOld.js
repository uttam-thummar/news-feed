import React, { Component } from 'react'
import NewsItem from './NewsItem'
import Spinner from './Spinner';
import PropTypes from 'prop-types'

export class NewsOld extends Component {
    static defaultProps = {
        pageSize: 9,
        country: 'in',
        category: 'general'
    }
    static propTypes = {
        pageSize: PropTypes.number,
        country: PropTypes.string,
        category: PropTypes.string,
    }

    capitalizeFirstLetter = (word) => {
        return word.charAt(0).toUpperCase() + word.slice(1);
    }

    constructor(props){
        super(props);
        this.state = {
            articles: [],
            loading: false,
            page: 1
        }
        document.title = `NewsMonkey - ${this.capitalizeFirstLetter(this.props.category)}`
    }

    async fetchNews(){
        const url = `https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=67fa22612c394f7b9e940ed04eb03aa9&pageSize=${this.props.pageSize}&page=${this.state.page}`;
            this.setState({loading: true});
            let data = await fetch(url);
            let parsedData = await data.json();
            this.setState({
                articles: parsedData.articles,
                totalResults: parsedData.totalResults,
                totalPage: Math.ceil(parsedData.totalResults/this.props.pageSize),
                loading: false
            });
    }

    async componentDidMount(){
        this.fetchNews();
    }

    handleNextClick = async () => {
        if((this.state.page+1) <= this.state.totalPage){
            this.setState({page: this.state.page + 1});
            this.fetchNews();
        }
    }

    handlePrevClick = async () => {
        if((this.state.page - 1) > 0){
            this.setState({page: this.state.page - 1});
            this.fetchNews();
        }
    }

    render() {
        return (
            <div className="container my-3">
                <h1 className='text-center' style={{margin: '35px 0'}}>NewsMonkey - Top {this.capitalizeFirstLetter(this.props.category)} Headlines</h1>
                {this.state.loading && <Spinner/>}
                <div className="row">
                    {!this.state.loading && this.state.articles.map((element) => {
                        return <div className="col-md-4" key={element.url}>
                            <NewsItem title={element.title} description={element.description} imageUrl={element.urlToImage} newsUrl={element.url} author={element.author} date={element.publishedAt} source={element.source.name}/>
                        </div>
                    })}
                </div>
                <div className=" d-flex justify-content-between">
                    <button disabled={this.state.page<=1} className="btn btn-dark mx-3" onClick={this.handlePrevClick}>&larr; Previous</button>
                    <button disabled={this.state.page >= this.state.totalPage} className="btn btn-dark" onClick={this.handleNextClick}>Next &rarr;</button>
                </div>
            </div>
        )
    }
}

export default NewsOld
