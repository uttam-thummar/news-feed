import React, { Component } from 'react'
import '../css/spinner.css';

export class Spinner extends Component {
    render() {
        return (
            <>
                <div className='text-center'>
                    <div className="loadingio-spinner-rolling">
                        <div className="ldio">
                            <div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default Spinner
