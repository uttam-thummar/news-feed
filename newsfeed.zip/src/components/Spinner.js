import React from 'react'
import '../css/spinner.css';

function Spinner() {
    return (
        <>
            <div className='text-center'>
                <div className="loadingio-spinner-rolling">
                    <div className="ldio">
                        <div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Spinner

